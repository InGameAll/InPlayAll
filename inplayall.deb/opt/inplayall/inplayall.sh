#!/bin/bash
source /opt/inplayall/env/bin/activate
python /opt/inplayall/main.py
