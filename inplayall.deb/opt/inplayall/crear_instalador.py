import subprocess
import os
import sys
os.system("/home/andy/PYTHON/InGameAll/InGameAll/Installer/install.sh")
os.system("/home/andy/PYTHON/InGameAll/InGameAll/Installer/run.sh")

def crear_entorno_virtual():
    """Crea un entorno virtual si no existe."""
    if not os.path.exists("inplayall_env"):
        print("Creando entorno virtual...")
        subprocess.run([sys.executable, "-m", "venv", "inplayall_env"])
        print("Entorno virtual creado.")

def instalar_dependencias():
    """Instala dependencias en el entorno virtual."""
    print("Instalando dependencias...")
    subprocess.run(["inplayall_env/bin/pip", "install", "-r", "requirements.txt"])
    print("Dependencias instaladas.")

def ejecutar_script(script):
    """Ejecuta un script en la shell."""
    subprocess.call(script, shell=True)

if __name__ == "__main__":
    print("Inicia instalación")
    crear_entorno_virtual()
    instalar_dependencias()
    ejecutar_script("/home/andy/PYTHON/InGameAll/InGameAll/Installer/install.sh")
    ejecutar_script("/home/andy/PYTHON/InGameAll/InGameAll/Installer/run.sh")
